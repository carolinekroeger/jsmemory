console.log('hello');

//define name and show on screen
const name='Glenda';
const nameElement = document.getElementById('name');
nameElement.textConent = name;
console.log('name element',nameElement);

//define age and show on screen
const age=22;
const ageElement = document.getElementById('age');
ageElement.textContent = age;

//create css classes for is good/not
//show the right word/class styles on the screen depnding
const isGood = true;
const goodClass = isGood ? 'good' : 'not-good';
const isGoodElement = document.getElementById('is-good');
isGoodElement.textContent = isGood;
